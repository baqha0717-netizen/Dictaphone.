package com.example.diktofonpesni;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private MediaRecorder recorder;
    private MediaPlayer player;
    private File recordingFile;
    private TextView status;
    private Button recordButton, stopButton, playButton;
    private boolean recording = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        updateButtons();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 100);
        }
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(0xFFF7F4FF);

        TextView title = new TextView(this);
        title.setText("🎤 Диктофон песен");
        title.setTextSize(28);
        title.setTextColor(0xFF39245F);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Записывай голос и слушай свои песни");
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 14, 0, 28);
        root.addView(subtitle);

        status = new TextView(this);
        status.setText("Готов к записи");
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 10, 0, 24);
        root.addView(status);

        recordButton = makeButton("⏺ Начать запись");
        stopButton = makeButton("⏹ Остановить");
        playButton = makeButton("▶ Прослушать последнюю запись");
        root.addView(recordButton, buttonParams());
        root.addView(stopButton, buttonParams());
        root.addView(playButton, buttonParams());

        TextView note = new TextView(this);
        note.setText("Записи хранятся внутри приложения в папке MusicRecordings.");
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, 28, 0, 0);
        root.addView(note);
        setContentView(root);

        recordButton.setOnClickListener(v -> startRecording());
        stopButton.setOnClickListener(v -> stopRecording());
        playButton.setOnClickListener(v -> playRecording());
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 8, 0, 8);
        return p;
    }

    private void startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 100);
            return;
        }
        try {
            File folder = new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "MusicRecordings");
            if (!folder.exists() && !folder.mkdirs()) {
                throw new IOException("Не удалось создать папку для записи");
            }
            String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault()).format(new Date());
            recordingFile = new File(folder, "Pesnya_" + stamp + ".m4a");

            if (Build.VERSION.SDK_INT >= 31) {
                recorder = new MediaRecorder(this);
            } else {
                recorder = new MediaRecorder();
            }
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(128000);
            recorder.setAudioSamplingRate(44100);
            recorder.setOutputFile(recordingFile.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            recording = true;
            status.setText("🔴 Идёт запись…");
            updateButtons();
        } catch (Exception e) {
            releaseRecorder();
            status.setText("Не удалось начать запись");
            Toast.makeText(this, "Ошибка записи: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void stopRecording() {
        if (!recording || recorder == null) return;
        try {
            recorder.stop();
            status.setText("Запись сохранена: " + recordingFile.getName());
            Toast.makeText(this, "Песня сохранена", Toast.LENGTH_SHORT).show();
        } catch (RuntimeException e) {
            status.setText("Запись слишком короткая — попробуй ещё раз");
            if (recordingFile != null) recordingFile.delete();
        } finally {
            recording = false;
            releaseRecorder();
            updateButtons();
        }
    }

    private void playRecording() {
        if (recordingFile == null || !recordingFile.exists()) {
            Toast.makeText(this, "Сначала запиши песню", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (player != null) {
                player.release();
                player = null;
            }
            player = new MediaPlayer();
            player.setDataSource(recordingFile.getAbsolutePath());
            player.setOnCompletionListener(mp -> {
                mp.release();
                player = null;
                status.setText("Воспроизведение завершено");
            });
            player.prepare();
            player.start();
            status.setText("▶ Играет: " + recordingFile.getName());
        } catch (IOException e) {
            Toast.makeText(this, "Не удалось воспроизвести запись", Toast.LENGTH_LONG).show();
        }
    }

    private void releaseRecorder() {
        if (recorder != null) {
            try { recorder.reset(); } catch (Exception ignored) {}
            try { recorder.release(); } catch (Exception ignored) {}
            recorder = null;
        }
    }

    private void updateButtons() {
        if (recordButton == null) return;
        recordButton.setEnabled(!recording);
        stopButton.setEnabled(recording);
        playButton.setEnabled(!recording && recordingFile != null && recordingFile.exists());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                status.setText("Доступ к микрофону разрешён. Готов к записи.");
            } else {
                status.setText("Разреши доступ к микрофону, чтобы записывать песни.");
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (recording) {
            try { recorder.stop(); } catch (Exception ignored) {}
        }
        releaseRecorder();
        if (player != null) {
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
        super.onDestroy();
    }
}
